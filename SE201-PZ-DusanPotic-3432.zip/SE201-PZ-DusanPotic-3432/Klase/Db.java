/***********************************************************************
 * Module:  Db.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Db
 ***********************************************************************/

import java.util.*;

/** @pdOid f7ced19e-2484-4154-9104-a052eb331e68 */
public class Db {
   /** @pdOid 3a977b8a-270d-4487-9391-3878751c78dd */
   private DB istance;
   
   /** @pdOid cf4e0355-1030-4a15-a372-7a2df0691209 */
   private Db() {
      // TODO: implement
   }
   
   /** @pdOid cfc51c96-2d97-4f13-a4d7-56f87df4a51e */
   public static DB getIstance() {
      // TODO: implement
      return null;
   }
   
   /** @param username 
    * @param password
    * @pdOid a1edac1c-f1ce-43a5-92e9-2517641e46f7 */
   public boolean check(String username, String password) {
      // TODO: implement
      return false;
   }
   
   /** @pdOid 1855285f-210e-432f-b0d2-6339e01f654f */
   public boolean checkProfesor() {
      // TODO: implement
      return false;
   }
   
   /** @pdOid 7012b102-10ff-4c4c-8a9a-b80fc6192c1e */
   public boolean checkStudent() {
      // TODO: implement
      return false;
   }
   
   /** @pdOid 6ebb2b4a-957f-4140-8460-ef2fe2bcc01c */
   public boolean checkSmer() {
      // TODO: implement
      return false;
   }
   
   /** @pdOid 12baf649-eda7-478f-ad9b-5fb54c2947b4 */
   public boolean checkPredmet() {
      // TODO: implement
      return false;
   }
   
   /** @param s
    * @pdOid 8ef3a70f-7093-4929-945f-ccab7172b31b */
   public void addStudent(Student s) {
      // TODO: implement
   }
   
   /** @param s
    * @pdOid c87985ad-0cc2-4c63-bd9e-de9608b893aa */
   public void deleteStudent(Student s) {
      // TODO: implement
   }
   
   /** @param s
    * @pdOid 115d9a90-46ef-4bf5-9693-62cfd0441bdb */
   public void updateStudent(Student s) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid 55a2343f-da9f-429c-8270-35d65f1d2be2 */
   public List<Student> getStudentList(Predmet p) {
      // TODO: implement
      return null;
   }
   
   /** @pdOid dd8a98e8-61a8-4a65-9440-c4bfb8f3945f */
   public List<Student> getStudentList() {
      // TODO: implement
      return null;
   }
   
   /** @param p
    * @pdOid 63b6a341-7706-468a-9e06-a3d83eac8403 */
   public void addProfesor(Profesor p) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid a1b26f59-aea0-41aa-a79c-c4cd17852a8b */
   public void deleteProfesor(Profesor p) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid 584ca250-8567-4c8c-8174-00a2c7d1e663 */
   public void updateProfesor(Profesor p) {
      // TODO: implement
   }
   
   /** @pdOid a36a3523-f4c6-4af3-98ee-431b09df69b4 */
   public List<Profesor> getProfesorList() {
      // TODO: implement
      return null;
   }
   
   /** @param s
    * @pdOid c128c579-5575-4fcb-b943-da039ae9acc0 */
   public void addSmer(Smer s) {
      // TODO: implement
   }
   
   /** @param s
    * @pdOid d1cf06e0-64d0-4cc0-93e2-c7a2178b3ffa */
   public void deleteSmer(Smer s) {
      // TODO: implement
   }
   
   /** @pdOid 8c715848-8d9d-484c-b03c-15add3c18f6c */
   public List<Smer> getSmerList() {
      // TODO: implement
      return null;
   }
   
   /** @param p
    * @pdOid 7d2224a5-d625-4f4c-bb54-a1a4f93d655f */
   public void addPredmet(Predmet p) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid 28e01f2a-b521-43da-82ed-ce46b23148b2 */
   public void deletePredmet(Predmet p) {
      // TODO: implement
   }
   
   /** @param s
    * @pdOid 313efb98-36fb-4125-a5f2-07cb46e471a2 */
   public List<Predmet> getPredmetList(Smer s) {
      // TODO: implement
      return null;
   }
   
   /** @param l
    * @pdOid 6eb3caf6-c06c-432f-8b8b-14352bbce0f2 */
   public void addLekcija(Lekcija l) {
      // TODO: implement
   }
   
   /** @param l
    * @pdOid d959d00a-f1b2-4492-a044-2fb43a9ec262 */
   public void deleteLekcija(Lekcija l) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid 9be7fdb3-c0e9-4c03-bd08-009f3c9fa8ee */
   public List<Lekcija> getLekcijaList(Predmet p) {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 173f7dd6-7639-4762-ad05-19651c334dcd */
   public List<Lekcija> getLekcijaList() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 637d210b-5cab-45e6-8fc6-1906f57e3d2c */
   public List<Predmet> getPredmetList() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 65c69bbf-9e9d-42b9-8033-c6777f49a7b0 */
   public List<ModelIspit> getModelIspitList() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 0ee5f451-6691-4ed8-b1dd-75f89f3b54f3 */
   public List<Ispit> getIspitList() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid cfd6221e-e9d7-43f8-90b4-5982d692dcfa */
   public List<IspitniRok> getIspitniRokList() {
      // TODO: implement
      return null;
   }
   
   /** @param i
    * @pdOid 2127e203-7c6d-46cd-a3f5-8e72a5d3877d */
   public void addIspit(Ispit i) {
      // TODO: implement
   }
   
   /** @pdOid d9fd9ee2-595d-45bb-978c-012eb7bb2571 */
   public List<SkolskaGodina> getSkolskaGodinaList() {
      // TODO: implement
      return null;
   }
   
   /** @param sk
    * @pdOid 5e770191-431c-43bf-9829-d1a58b59c176 */
   public List<Predmet> getPredmetList(SkolskaGodina sk) {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 8966489c-7fe8-4675-936a-ae2f281a5941 */
   public PredispitneObaveze getPredispitnaObaveza() {
      // TODO: implement
      return null;
   }
   
   /** @param p
    * @pdOid 4b35f6dc-53ca-4123-bc31-bfb835cf0d43 */
   public List<Predmet> zahtevListaPredmeta(Profesor p) {
      // TODO: implement
      return null;
   }
   
   /** @param p
    * @pdOid df8c16ca-a793-4f71-b0e5-0077ba09b0e2 */
   public List<PredispitneObaveze> getPredispitneObavezeList(Predmet p) {
      // TODO: implement
      return null;
   }
   
   /** @param p
    * @pdOid 3f32ec95-e5cf-480a-9d3b-fbce002e6cc2 */
   public void addPredispitneObaveze(PredispitneObaveze p) {
      // TODO: implement
   }
   
   /** @param sk
    * @pdOid d9d97026-392d-45e0-aa5e-6af2162d7d84 */
   public List<Rok> getRokList(SkolskaGodina sk) {
      // TODO: implement
      return null;
   }
   
   /** @param p 
    * @param r
    * @pdOid 7a4ecc5a-7ed5-44fc-b7f9-e9d22b002b15 */
   public List<ModelIspita> getModelIspitaList(Profesor p, Rok r) {
      // TODO: implement
      return null;
   }
   
   /** @param mi
    * @pdOid 9fc14b3f-7c3a-4d53-ba08-333041e15079 */
   public List<Student> zahtevListaStudenataa(ModelIspita mi) {
      // TODO: implement
      return null;
   }
   
   /** @param s 
    * @param mi
    * @pdOid 49506aa3-5d1a-4f72-ab27-7986b30c5f1e */
   public Ispit getIspit(Student s, ModelIspita mi) {
      // TODO: implement
      return null;
   }
   
   /** @param i 
    * @param poeni
    * @pdOid fb321a04-47e9-4327-a211-57ff47a44df2 */
   public void addIspitnePoene(Ispit i, int poeni) {
      // TODO: implement
   }
   
   /** @param l
    * @pdOid 9ba8ed97-9157-48bf-b129-24dcf896303d */
   public Lekcija getLekcija(Lekcija l) {
      // TODO: implement
      return null;
   }

}