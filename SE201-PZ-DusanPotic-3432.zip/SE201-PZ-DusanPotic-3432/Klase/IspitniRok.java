/***********************************************************************
 * Module:  IspitniRok.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class IspitniRok
 ***********************************************************************/

import java.util.*;

/** @pdOid 284c705c-bf01-49e6-bab0-deb8b014fed3 */
public class IspitniRok {
   /** @pdOid 3ce1a227-77b0-4e7e-8fbe-48aa6f2955b5 */
   private Date datumPocetka;
   /** @pdOid bbf3009a-ce75-438f-9d73-3d37166df825 */
   private Date datumZavrsetka;
   /** @pdOid 99e40231-e88d-4ca9-8c28-90afc7ea96fd */
   private Date datumPocetkaPrijave;
   /** @pdOid 14f08948-73ff-4340-a2d8-c0f630b1ea1c */
   private Date datumZavrsetkaPrijave;
   
   /** @pdOid fe39ef7d-d45e-4d7c-aa13-2780ca605b68 */
   public IspitniRok() {
      // TODO: implement
   }

}