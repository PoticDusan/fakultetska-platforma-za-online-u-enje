/***********************************************************************
 * Module:  Student.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Student
 ***********************************************************************/

import java.util.*;

/** @pdOid b193ffa0-15ce-4951-ac9b-e68ad7336f49 */
public class Student extends Korisnik {
   /** @pdOid 2bfdbba2-d8b3-452c-9ed5-3ca915be8951 */
   private int studentID;
   /** @pdOid 46d730d1-d7ff-4cca-b43b-b7ae754b6705 */
   private int indeks;
   /** @pdOid 3ed069f0-ffbf-48a3-973c-6c01cd12e0f5 */
   private int godinaStudija;
   
   /** @pdOid 48311e44-5722-4248-b3e9-6d2d5f0ce5e7 */
   public Student() {
      // TODO: implement
   }
   
   /** @pdOid c3312c82-1440-47aa-8b9a-0c43b0baffb2 */
   public int getStudentID() {
      return studentID;
   }
   
   /** @param newStudentID
    * @pdOid 8cc5c3d1-3f9c-424c-9e07-0ac2d0cf18f5 */
   public void setStudentID(int newStudentID) {
      studentID = newStudentID;
   }
   
   /** @pdOid f87ac8a6-ecd8-4c60-a6ee-82ec35f359c3 */
   public int getIndeks() {
      return indeks;
   }
   
   /** @param newIndeks
    * @pdOid 0bf627d3-cbf6-4e0d-9f02-d944d2b82c56 */
   public void setIndeks(int newIndeks) {
      indeks = newIndeks;
   }
   
   /** @pdOid e6b32a90-5d2d-4b69-9ef3-c88b8eff5cf4 */
   public int getGodinaStudija() {
      return godinaStudija;
   }
   
   /** @param newGodinaStudija
    * @pdOid 985cd896-ce83-4281-9a63-ede018f7910e */
   public void setGodinaStudija(int newGodinaStudija) {
      godinaStudija = newGodinaStudija;
   }

}