/***********************************************************************
 * Module:  Predmet.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Predmet
 ***********************************************************************/

import java.util.*;

/** @pdOid c62a8921-46cf-4f2c-b487-15849e8a0c96 */
public class Predmet {
   /** @pdOid 7d47f9b5-c5a8-4b90-aa75-1268bda80f37 */
   private int predmetID;
   /** @pdOid 82d4d5c2-1f14-4522-be40-8dd950d7844d */
   private String naziv;
   /** @pdOid 481a89db-4adb-49ab-8d9d-2672cb579596 */
   private int semestar;
   /** @pdOid c599df41-fe0c-4a4d-ba34-38d8278d4c0c */
   private int espb;
   /** @pdOid bb94fd17-4556-4536-a663-0e6177f65ede */
   private List<Lekcija> listaLekcija;
   
   /** @pdRoleInfo migr=no name=TipPredmeta assc=association38 mult=1..1 */
   public TipPredmeta tipPredmeta;
   
   /** @pdOid 1b026a30-9f9d-4398-8a1a-168366e15c15 */
   public Predmet() {
      // TODO: implement
   }
   
   /** @pdOid 2f3918d4-337e-4b42-a264-b539ba53d53b */
   public int getPredmetID() {
      return predmetID;
   }
   
   /** @param newPredmetID
    * @pdOid db15170a-9302-4ce4-a55a-dac3e5a7ba07 */
   public void setPredmetID(int newPredmetID) {
      predmetID = newPredmetID;
   }
   
   /** @pdOid 66f6351c-d89b-4ab3-b49e-724fd8a7415b */
   public String getNaziv() {
      return naziv;
   }
   
   /** @param newNaziv
    * @pdOid 1eccee45-b23a-4f1f-9688-b30e4c7b1851 */
   public void setNaziv(String newNaziv) {
      naziv = newNaziv;
   }
   
   /** @pdOid 5cf8bb10-3dfe-4f18-bb8e-3678d14bb7e6 */
   public List<Lekcija> getListaLekcija() {
      return listaLekcija;
   }
   
   /** @param newListaLekcija
    * @pdOid bea1d6c7-b21c-4c33-a90d-5d89958ed33c */
   public void setListaLekcija(List<Lekcija> newListaLekcija) {
      listaLekcija = newListaLekcija;
   }

}