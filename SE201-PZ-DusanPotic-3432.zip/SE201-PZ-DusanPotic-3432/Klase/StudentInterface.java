/***********************************************************************
 * Module:  StudentInterface.java
 * Author:  Potic-Win10
 * Purpose: Defines the Interface StudentInterface
 ***********************************************************************/

import java.util.*;

/** @pdOid 8b9fcac1-332d-48a5-b8dc-d67cf7d27941 */
public interface StudentInterface {
   /** @param username 
    * @param password
    * @pdOid 6721f98a-1b73-4998-81dd-e1293b8b17b3 */
   Korisnik login(String username, String password);
   /** @param p
    * @pdOid 1e1ad3af-77ae-43df-bb27-71194e278d22 */
   List<Lekcija> zahtevListaLekcija(Predmet p);
   /** @param p
    * @pdOid 4efb1e02-7225-4a92-b944-ebab9f771e8b */
   List<PredispitneObavezet> zahtevListaPredispitnihObaveza(Predmet p);
   /** @param s
    * @pdOid 4c642b29-28bc-44ba-9fbb-c2f768b77433 */
   Lista<Predmet> zahtevListaPredmeta(Smer s);
   /** @param s
    * @pdOid a80bbd23-4406-4c0f-bad0-b78e40ef1421 */
   List<Ispit> zahtevListaIspita(Student s);
   /** @param i
    * @pdOid a911999e-0e5a-492d-8ebb-ee13c2f8b15f */
   void zahtevPrijavaIspita(Ispit i);
   /** @pdOid eb311216-a651-46d1-be60-a3c8e4630929 */
   List<SkolskaGodina> zahtevListaSkolskihGodina();
   /** @param sk
    * @pdOid 51396a31-5892-4db3-b736-be94b3722c2f */
   List<IspitniRok> zahtevListaRokova(SkolskaGodina sk);

}