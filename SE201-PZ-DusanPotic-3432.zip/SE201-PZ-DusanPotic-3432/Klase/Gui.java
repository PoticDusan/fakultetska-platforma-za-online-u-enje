/***********************************************************************
 * Module:  Gui.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Gui
 ***********************************************************************/

import java.util.*;

/** @pdOid 6d1d807b-4f9e-4806-a5e9-37683a0e1049 */
public class Gui {
   /** @pdOid c110ac16-254d-46d9-9aa9-caf67959944c */
   public void main() {
      // TODO: implement
   }
   
   /** @pdOid 8367fa97-0f08-4699-bfc6-c64938062341 */
   public void openFormLogin() {
      // TODO: implement
   }
   
   /** @pdOid 3579bbb8-52a6-469c-a3a9-29977329a248 */
   public void openFormAdmin() {
      // TODO: implement
   }
   
   /** @pdOid f044c067-5682-4f49-8ee6-320d3f993d61 */
   public void openFormProfesor() {
      // TODO: implement
   }
   
   /** @pdOid 4238031e-4555-4c9d-a547-af06021bbf0c */
   public void openFormStudent() {
      // TODO: implement
   }
   
   /** @pdOid 458d2cf2-5e03-4844-bf9c-5251b159c948 */
   public void onClickAddStudent() {
      // TODO: implement
   }
   
   /** @pdOid 4c5960c3-f610-425f-9ddd-18d22dd6cf86 */
   public void onClickAddProfesor() {
      // TODO: implement
   }
   
   /** @pdOid 885070ef-4e3d-4a7f-865a-ac45e9e778af */
   public void onClickAddSmer() {
      // TODO: implement
   }
   
   /** @pdOid 5a44b3a3-c62c-406d-931b-af66383fe240 */
   public void onClickAddLekcija() {
      // TODO: implement
   }
   
   /** @pdOid 6ccaa81b-229e-4878-961c-2116bbbe2f8c */
   public void onClickAddPredmet() {
      // TODO: implement
   }
   
   /** @pdOid 3890f114-2be1-462a-86ac-08b208dc5054 */
   public void onClickListaStudenata() {
      // TODO: implement
   }
   
   /** @pdOid ba983bb6-6b9c-4941-bc69-d71a90ef94a0 */
   public void onClickListaProfesora() {
      // TODO: implement
   }
   
   /** @pdOid a9d3911b-39cb-4da4-b2e9-40a895d8319f */
   public void onClickListaLekcija() {
      // TODO: implement
   }
   
   /** @pdOid 6c77bf41-fa62-4e3d-915e-e661a8b1f266 */
   public void onClickListaSmerova() {
      // TODO: implement
   }
   
   /** @pdOid 73b61c70-3954-4567-9126-a7be6158c61d */
   public void onClickObrisiProfesora() {
      // TODO: implement
   }
   
   /** @pdOid e9c6076f-993f-40f3-91c0-650acfff2e82 */
   public void onClickObrisiStudenta() {
      // TODO: implement
   }
   
   /** @pdOid 973d24da-5a92-47e0-a36d-49fbcbc3b72e */
   public void onClickObrisiSmer() {
      // TODO: implement
   }
   
   /** @pdOid 6ab80ff7-82c9-4f10-a109-00adb726e9bd */
   public void onClickObrisiPredmet() {
      // TODO: implement
   }
   
   /** @pdOid ec752605-a9a9-49b3-b050-7bd7d102bc85 */
   public void onClickObrisiLekciju() {
      // TODO: implement
   }
   
   /** @pdOid 034a6af3-785f-4caa-8c32-a30307d0420a */
   public void onClickPrikaziStudenta() {
      // TODO: implement
   }
   
   /** @pdOid 1537fbfb-017d-4053-807b-abba314977ee */
   public void onClickPrikaziProfesora() {
      // TODO: implement
   }
   
   /** @pdOid 3e6c6cf1-8fdd-44d7-89f3-f29909329019 */
   public void onClickPrikaziSmer() {
      // TODO: implement
   }
   
   /** @pdOid be07d818-19d4-4642-90f7-c238f275a981 */
   public void onClickPrikaziPredmet() {
      // TODO: implement
   }
   
   /** @pdOid a0eab725-8dfb-4e87-9144-9999373f777c */
   public void onClickPrikaziLekciju() {
      // TODO: implement
   }
   
   /** @pdOid 359c3ae4-1315-4fc5-887f-ddd2cbf16899 */
   public void showMessage() {
      // TODO: implement
   }
   
   /** @pdOid 43abc83e-ba14-48fb-93f2-3b23a0901b89 */
   public void showAlert() {
      // TODO: implement
   }
   
   /** @pdOid 2311970c-4d57-4fb8-a0cc-d51bc9742a1b */
   public void onClickPrijavaIspita() {
      // TODO: implement
   }
   
   /** @param sk
    * @pdOid 0db6e179-168e-4ac6-ac4e-a61ccdf591fe */
   public void onClickListaPredmeta(SkolskaGodina sk) {
      // TODO: implement
   }
   
   /** @pdOid 052fa816-7172-4d5b-b900-f07674c90407 */
   public void onClickPrikaziPredispitneObaveze() {
      // TODO: implement
   }
   
   /** @pdOid 26399e77-1e23-4720-b9c3-b62c3593a64b */
   public void onClickDodajPredispitnePoene() {
      // TODO: implement
   }
   
   /** @pdOid ebe14ebc-8e07-4326-ae6c-e2779d847ffc */
   public void onClickDodajIspitnePoene() {
      // TODO: implement
   }
   
   /** @pdOid 5459adc1-d681-487e-bad2-ca4954dabf03 */
   public void onClickUpdateStudent() {
      // TODO: implement
   }
   
   /** @pdOid ad147329-7f2b-4a73-a0be-e7a87c3fe592 */
   public void onClickUpdateProfesor() {
      // TODO: implement
   }

}