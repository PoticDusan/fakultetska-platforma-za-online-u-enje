/***********************************************************************
 * Module:  Nastava.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Nastava
 ***********************************************************************/

import java.util.*;

/** @pdOid 53431624-6b37-49c8-8499-9649d2bb0017 */
public class Nastava {
   /** @pdOid a0db914e-7100-45bc-9781-c4c2c04c627d */
   public Nastava() {
      // TODO: implement
   }

}