/***********************************************************************
 * Module:  Ispit.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Ispit
 ***********************************************************************/

import java.util.*;

/** @pdOid 75653903-85e0-4f48-b098-f3f1ad46cfaf */
public class Ispit {
   /** @pdOid 9f8f1c42-bf36-4bda-bb0e-d5aeeac84924 */
   private int ispitID;
   /** @pdOid 7d86126d-d466-4669-bd3d-cd632b4df4ff */
   private double predispitniPoeni;
   /** @pdOid cf765a74-7560-454e-a5f2-28750952ebcc */
   private double ispitniPoeni;
   /** @pdOid 0f5d75eb-6dcd-4f66-a560-50434f732e84 */
   private double ukupnoPoeni;
   /** @pdOid f2ea9e21-1d76-45c6-ae82-b8d5012458da */
   private int ocena;
   
   /** @pdOid 6d18079c-5b0a-4c00-844a-f83f60c3abbd */
   public Ispit() {
      // TODO: implement
   }
   
   /** @pdOid 4b1524ca-53c5-487b-a6db-ce73949074d1 */
   public int getIspitID() {
      return ispitID;
   }
   
   /** @param newIspitID
    * @pdOid d3c6aaf4-4e27-479f-b35d-fff44cccf212 */
   public void setIspitID(int newIspitID) {
      ispitID = newIspitID;
   }
   
   /** @pdOid 69c309fe-6d45-41cb-a2c6-66ce83f99e95 */
   public double getPredispitniPoeni() {
      return predispitniPoeni;
   }
   
   /** @param newPredispitniPoeni
    * @pdOid e805ec91-5564-4127-98c5-551c8e865ddd */
   public void setPredispitniPoeni(double newPredispitniPoeni) {
      predispitniPoeni = newPredispitniPoeni;
   }
   
   /** @pdOid f723d012-bf10-488c-98f1-c1ca5cba67bb */
   public double getIspitniPoeni() {
      return ispitniPoeni;
   }
   
   /** @param newIspitniPoeni
    * @pdOid fd71276e-6aa6-4b2e-b389-d31750e6b620 */
   public void setIspitniPoeni(double newIspitniPoeni) {
      ispitniPoeni = newIspitniPoeni;
   }
   
   /** @pdOid 7197b070-088e-4db1-96d6-6fd7c0411a48 */
   public double getUkupnoPoeni() {
      return ukupnoPoeni;
   }
   
   /** @param newUkupnoPoeni
    * @pdOid eb765871-bb0b-4e26-9e4b-8390f95d1d9f */
   public void setUkupnoPoeni(double newUkupnoPoeni) {
      ukupnoPoeni = newUkupnoPoeni;
   }
   
   /** @pdOid 5d21d6fb-b2b9-4c28-8f0f-7ad2493660b0 */
   public int getOcena() {
      return ocena;
   }
   
   /** @param newOcena
    * @pdOid c09ddcbd-8bf4-47aa-a394-0409be97d045 */
   public void setOcena(int newOcena) {
      ocena = newOcena;
   }

}