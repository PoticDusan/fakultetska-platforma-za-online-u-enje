/***********************************************************************
 * Module:  SkolskaGodina.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class SkolskaGodina
 ***********************************************************************/

import java.util.*;

/** @pdOid 9b33761c-0cdd-445f-a206-22644bec6232 */
public class SkolskaGodina {
   /** @pdOid acfbd67c-ce91-4ecb-a183-a6ce5782fb74 */
   private int skolskaGodinaID;
   /** @pdOid f73adf67-315a-4135-952f-90ba43c8a796 */
   private String naziv;
   /** @pdOid 192506e9-a62c-44fc-a509-02afb00c1496 */
   private Date pocetak;
   /** @pdOid 17cb9d0d-f588-4b42-b5f5-168df266749b */
   private Date kraj;
   
   /** @pdOid 472fe7e4-6606-4feb-9aa1-c83f54314091 */
   public SkolskaGodina() {
      // TODO: implement
   }

}