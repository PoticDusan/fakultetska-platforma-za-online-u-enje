/***********************************************************************
 * Module:  Control.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Control
 ***********************************************************************/

import java.util.*;

/** @pdOid 03f76374-3fec-4f05-aa61-c3e42ff5be51 */
public class Control implements StudentInterface, AdminInterface, ProfesorInterface {
   /** @pdOid 29627551-9d1a-4e2d-aba6-2cb943b958b2 */
   private PrijavaIspita pi;
   
   /** @param username 
    * @param password
    * @pdOid cbad2315-a25a-40e4-b061-f1d1067a0050 */
   public Korisnik login(String username, String password)
   
   /** @param p
    * @pdOid 88950f18-8ec0-4a40-999d-181c35d25c1b */
   public List<Lekcija> zahtevListaLekcija(Predmet p)
   
   /** @param p
    * @pdOid 85a097d2-338f-4ec1-b4b1-a05b8c965859 */
   public List<PredispitneObavezet> zahtevListaPredispitnihObaveza(Predmet p)
   
   /** @param s
    * @pdOid 83b479aa-0991-40fd-923e-6283cb14726d */
   public Lista<Predmet> zahtevListaPredmeta(Smer s)
   
   /** @param s
    * @pdOid aab3ae26-c148-48b9-83f7-65bb137db585 */
   public List<Ispit> zahtevListaIspita(Student s)
   
   /** @param pi
    * @pdOid 9f533db3-9c7f-4439-98cd-d666ed63633a */
   public void zahtevPrijavaIspita(PrijavaIspita pi)
   
   /** @param p
    * @pdOid 6fb87abf-b2c4-4bfe-b2ca-dc18049ef5e3 */
   public void zahtevDodajPredispitneObaveze(PredispitneObaveze p)
   
   /** @param i
    * @pdOid 90204669-6944-4648-8801-170c37668dc1 */
   public void zahtevDodajIspitnePoene(Ispit i)
   
   /** @pdOid 75a9092e-7def-417a-8e11-cceb38ee9dd6 */
   public List<SkolskaGodina> zahtevListaSkolskihGodina()
   
   /** @param sk
    * @pdOid 86502cca-f69f-4dd3-9eae-c0f7c7d024b2 */
   public List<Rok> zahtevListaRokova(SkolskaGodina sk)
   
   /** @pdOid f2e1b632-e333-4d0b-831b-40a3f449cde8 */
   public List<Smer> zahtevListaSmerova()
   
   /** @param p 
    * @param s
    * @pdOid 645f62ea-aae0-460f-bc6c-c0ee6478a57e */
   public List<PredispitneObaveze> zahtevListaPredispitnihObaveza(Predmet p, Student s)
   
   /** @param l
    * @pdOid 32c11a42-5d01-4fc7-82db-0dd5034f077f */
   public void zahtevPrikazLekcije(Lekcija l)
   
   /** @param s
    * @pdOid e606c0c8-2216-4036-a58c-8212d7ecffba */
   public void zahtevDodajStudenta(Student s) {
      // TODO: implement
   }
   
   /** @param s
    * @pdOid 9b382047-5478-48b2-9f69-e25b9db43d43 */
   public void zahtevObrisiStudenta(Student s) {
      // TODO: implement
   }
   
   /** @param s
    * @pdOid 76e08b7b-a404-472c-960d-dbc665be18ec */
   public void zahtevAzurirajStudenta(Student s) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid c00f1671-4492-4165-8203-b1d1aa8b1346 */
   public List<Student> zahtevListaStudenata(Predmet p)
   
   /** @pdOid d32dc3c9-e1ef-4fba-8e0b-eef8b06ab59a */
   public List<Student> zahtevListaStudenata() {
      // TODO: implement
      return null;
   }
   
   /** @param p
    * @pdOid 97fa72b5-e5cc-487a-86c4-6eda1319e6e9 */
   public void zahtevDodajProfesora(Profesor p) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid ad5c5943-2ab2-4988-9cc3-a0f9dabe5d60 */
   public void zahtevObrisiProfesora(Profesor p) {
      // TODO: implement
   }
   
   /** @param p
    * @pdOid 7d05bc7f-933c-4c33-9756-27c38b13cc49 */
   public void zahtevAzurirajProfesora(Profesor p) {
      // TODO: implement
   }
   
   /** @pdOid c5ba9f82-c5cb-4fa3-b3be-40b03208b17e */
   public List<Profesor> zahtevListaProfesora() {
      // TODO: implement
      return null;
   }
   
   /** @param s
    * @pdOid 70d518d1-a4db-4e0a-a5f4-23a985b76a7a */
   public void zahtevDodajSmer(Smer s)
   
   /** @param s
    * @pdOid 7ae2adc5-a29b-4b7c-a0e8-af8248917c76 */
   public void zahtevObrisiSmer(Smer s)
   
   /** @param p
    * @pdOid 8aeaf96c-37b6-410c-8922-7aeecc0cd55d */
   public void zahtevDodajPredmet(Predmet p)
   
   /** @param p
    * @pdOid 439feabe-d43d-4485-b4a1-6b0151a7c7c9 */
   public void zahtevObrisiPredmet(Predmet p)
   
   /** @pdOid a5b7bd1d-11d7-453d-9b8e-a03da447896c */
   public List<Predmet> zahtevListaPredmeta()
   
   /** @param l
    * @pdOid 5934b1f0-260a-4181-bd11-48e2d136569f */
   public void zahtevDodajLekciju(Lekcija l)
   
   /** @param l
    * @pdOid 29db9dd6-8b80-40a3-9d87-767b0263654b */
   public void zahtevObrisiLekciju(Lekcija l)
   
   /** @pdOid 324a06ed-0a3a-409f-8dc0-4f9b529052e1 */
   public List<Lekcija> zahtevListaLekcija()
   
   /** @pdOid 0154dbea-8005-46cd-be0c-e0728ec1b5be */
   public List<ModelIspita> zahtevListaModelaIspita() {
      // TODO: implement
      return null;
   }
   
   /** @param sk
    * @pdOid 9d29ee59-22ad-4bcc-8e14-c1e77f452741 */
   public List<Predmet> zahtevListaPredmeta(SkolskaGodina sk) {
      // TODO: implement
      return null;
   }
   
   /** @param p
    * @pdOid 90752b1c-9c67-46d9-aa78-3eaf1395265d */
   public List<Predmet> zahtevListaPredmeta(Profesor p) {
      // TODO: implement
      return null;
   }
   
   /** @param p 
    * @param r
    * @pdOid ef8d5560-1c85-4016-9821-380ec90e6ec2 */
   public List<ModelIspita> zahtevListaModelaIspita(Profesor p, Rok r) {
      // TODO: implement
      return null;
   }
   
   /** @param mi
    * @pdOid 36994a52-f8df-4f63-8954-3a08de8e5b78 */
   public List<Student> zahtevListaStudenata(ModelIspita mi) {
      // TODO: implement
      return null;
   }
   
   /** @param s 
    * @param mi
    * @pdOid e2bd165d-c6a3-4be7-8a16-e572af136fc8 */
   public Ispit zahtevVratiIspit(Student s, ModelIspita mi) {
      // TODO: implement
      return null;
   }
   
   /** @param s
    * @pdOid bf2b36be-d8f0-4ede-90b0-c80149b47318 */
   public List<Predmet> zahtevListaPredmeta(Student s) {
      // TODO: implement
      return null;
   }

}