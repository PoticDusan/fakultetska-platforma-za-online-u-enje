/***********************************************************************
 * Module:  ModelIspit.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class ModelIspit
 ***********************************************************************/

import java.util.*;

/** @pdOid 010a16a8-d699-4941-9063-3841b7315d99 */
public class ModelIspit {
   /** @pdOid dc257cf8-d2ae-4d1d-b412-02edd00a8ab1 */
   private int modelIspitaID;
   /** @pdOid a51f22e9-5d94-48bd-827e-ad813f2b0cbe */
   private String naziv;
   /** @pdOid 40ecec5d-f955-473c-bdf4-3877aad37723 */
   private Date datum;
   /** @pdOid 1d84bc8a-e7e4-4f93-bc01-d58fbdf1d28b */
   private String vreme;
   /** @pdOid 1d32d63f-7f72-4b22-8a04-c4798b6f6600 */
   private String ucionica;
   
   /** @pdOid 0cddf079-6a0d-4775-8c3e-937c53aba15c */
   public ModelIspit() {
      // TODO: implement
   }

}