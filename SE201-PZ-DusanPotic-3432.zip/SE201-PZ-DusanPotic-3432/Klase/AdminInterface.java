/***********************************************************************
 * Module:  AdminInterface.java
 * Author:  Dusan
 * Purpose: Defines the Interface AdminInterface
 ***********************************************************************/

import java.util.*;

/** @pdOid 5d9dc07b-ee31-4515-a51a-fb525fd8dbd3 */
public interface AdminInterface {
   /** @param username 
    * @param password
    * @pdOid b3380b5c-a496-4d7f-93aa-672b02a767a3 */
   Korisnik login(String username, String password);
   /** @param s
    * @pdOid ad7d9288-e2b5-4cbe-81ff-f70282fac6be */
   void zahtevDodajStudenta(Student s);
   /** @param s
    * @pdOid f537e0fa-97b7-4a99-9b62-f031acf12833 */
   void zahtevObrisiStudenta(Student s);
   /** @param s
    * @pdOid f272b890-5810-43bc-b3b4-22f8488252be */
   void zahtevAzurirajStudenta(Student s);
   /** @pdOid 6962cbb7-d827-447c-8875-74f2bac5d6c4 */
   List<Student> zahtevListaStudenata();
   /** @param p
    * @pdOid ea39f5d5-0aa6-4aff-858f-0bcc048053a0 */
   void zahtevDodajProfesora(Profesor p);
   /** @param p
    * @pdOid 4db282a4-5abb-40a5-b8fa-cc7d8c5c6c59 */
   void zahtevObrisiProfesora(Profesor p);
   /** @param p
    * @pdOid bb1cbaff-a75e-488e-a24e-da9a90cb8b38 */
   void zahtevAzurirajProfesora(Profesor p);
   /** @pdOid ec8cea97-89db-4022-a715-e82dd65d3893 */
   List<Profesor> zahtevListaProfesora();
   /** @param s
    * @pdOid 576cad56-a4f1-4128-be98-2cd803b91bb9 */
   void zahtevDodajSmer(Smer s);
   /** @param s
    * @pdOid bf920ae5-163e-4145-9e9c-a164383cec1b */
   void zahtevObrisiSmer(Smer s);
   /** @pdOid 072fe4cc-d044-40df-b5fb-9398f5213bce */
   List<Smer> zahtevListaSmerova();
   /** @param p
    * @pdOid d2a2de11-97bc-406b-815c-d10d64652495 */
   void zahtevDodajPredmet(Predmet p);
   /** @param p
    * @pdOid df053f12-3a56-43bc-8519-2d9518888b16 */
   void zahtevObrisiPredmet(Predmet p);
   /** @pdOid fd081f63-f279-420f-a7ea-51b289a61755 */
   List<Predmet> zahtevListaPredmeta();
   /** @param l
    * @pdOid 7c283843-496c-4101-86f0-85d917b6681f */
   void zahtevDodajLekciju(Lekcija l);
   /** @param l
    * @pdOid 0b6e5347-bc8a-4a37-b91a-8b593db59dde */
   void zahtevObrisiLekciju(Lekcija l);
   /** @pdOid cbb6d973-102c-435c-af04-c36151b4712f */
   List<Lekcija> zahtevListaLekcija();

}