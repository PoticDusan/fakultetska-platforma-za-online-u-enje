/***********************************************************************
 * Module:  Smer.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Smer
 ***********************************************************************/

import java.util.*;

/** @pdOid df6bd7e1-7460-464e-a4c4-97900873a026 */
public class Smer {
   /** @pdOid 3d083dee-5e04-4ad8-a456-3233f2762692 */
   private int smerID;
   /** @pdOid 04a24464-38d6-43ca-831d-be391a0ce4ae */
   private String naziv;
   /** @pdOid 102cd462-3b90-4b30-b765-285a02f28b69 */
   private List<Predmet> listaPredmeta;
   
   /** @pdOid 9d86fbdc-c862-4ceb-b2ce-9b4afa171415 */
   public Smer() {
      // TODO: implement
   }
   
   /** @pdOid ba2dc015-2778-48b6-a22e-e799a8c1baf9 */
   public int getSmerID() {
      return smerID;
   }
   
   /** @param newSmerID
    * @pdOid 6fec7d1b-468d-4589-9f75-b66038f11c04 */
   public void setSmerID(int newSmerID) {
      smerID = newSmerID;
   }
   
   /** @pdOid 9696bf24-9237-4d7c-9c49-a31cc8585a36 */
   public String getNaziv() {
      return naziv;
   }
   
   /** @param newNaziv
    * @pdOid 6e594d20-5a58-4f45-bfe9-257b50eae6ee */
   public void setNaziv(String newNaziv) {
      naziv = newNaziv;
   }
   
   /** @pdOid fdc8d94c-cc51-4473-aa27-ac8b481d03da */
   public List<Predmet> getListaPredmeta() {
      return listaPredmeta;
   }
   
   /** @param newListaPredmeta
    * @pdOid f762bb56-26ab-40a7-bf26-3db7edf47f98 */
   public void setListaPredmeta(List<Predmet> newListaPredmeta) {
      listaPredmeta = newListaPredmeta;
   }

}