/***********************************************************************
 * Module:  IspitBuilder.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class IspitBuilder
 ***********************************************************************/

import java.util.*;

/** @pdOid a83ccefb-8872-4571-a082-b8b0cd049394 */
public abstract class IspitBuilder {
   /** @pdOid 9679ed2c-16c6-4494-bad7-d303497e4bfc */
   protected int ispit;
   
   /** @pdOid 5fd48fd1-f8e7-49e2-beff-5ea3c3a4045e */
   public void createIspit() {
      // TODO: implement
   }
   
   /** @pdOid f906040a-3ab9-4992-ac62-3ce5b529bc0b */
   public Ispit getIspit() {
      // TODO: implement
      return null;
   }
   
   /** @pdOid 0663e55a-3ee5-4602-812d-32d2e929bd66 */
   public void setPredIspitniPoeni() {
      // TODO: implement
   }
   
   /** @pdOid f3fbcbc9-68c3-400a-a5ad-b99d7c29647e */
   public void setIspitniPoeni() {
      // TODO: implement
   }
   
   /** @pdOid d0360df1-5e14-4cc8-92f3-f4cb7300d0eb */
   public void setUkupniPoeni() {
      // TODO: implement
   }
   
   /** @pdOid 1a660226-21f5-4051-9941-c78de837a55f */
   public void setOcena() {
      // TODO: implement
   }

}