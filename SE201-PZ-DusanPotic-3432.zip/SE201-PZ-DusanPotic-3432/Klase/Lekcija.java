/***********************************************************************
 * Module:  Lekcija.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Lekcija
 ***********************************************************************/

import java.util.*;

/** @pdOid 5cf9cb10-33eb-4d5d-b01b-2899760b9ee4 */
public class Lekcija {
   /** @pdOid 1619c0e8-3c40-444f-b039-226267111a69 */
   private int lekcijaID;
   /** @pdOid 86776b3b-3658-4fdd-802a-c72e3330f728 */
   private String naziv;
   /** @pdOid 50e6a793-a504-44d9-8217-beaf4e465ffc */
   private String url;
   
   /** @pdOid 58fafd86-1510-4688-a4c6-4f908b1ebb8d */
   public Lekcija() {
      // TODO: implement
   }
   
   /** @pdOid 12c00294-1e29-4eb0-a64b-c804ba802f73 */
   public int getLekcijaID() {
      return lekcijaID;
   }
   
   /** @param newLekcijaID
    * @pdOid f57a13ac-34c9-4718-b849-2d265c3f739f */
   public void setLekcijaID(int newLekcijaID) {
      lekcijaID = newLekcijaID;
   }
   
   /** @pdOid 9c396222-8baa-4ac1-8ab1-7332e7412f00 */
   public String getNaziv() {
      return naziv;
   }
   
   /** @param newNaziv
    * @pdOid abf7a5bc-d486-4f67-8aae-1d71bc334802 */
   public void setNaziv(String newNaziv) {
      naziv = newNaziv;
   }
   
   /** @pdOid ba0794e0-bf40-488e-8446-99a8f93b3b79 */
   public String getUrl() {
      return url;
   }
   
   /** @param newUrl
    * @pdOid d9d74cf4-6a9b-4de0-8bf2-e0912d20aa19 */
   public void setUrl(String newUrl) {
      url = newUrl;
   }

}