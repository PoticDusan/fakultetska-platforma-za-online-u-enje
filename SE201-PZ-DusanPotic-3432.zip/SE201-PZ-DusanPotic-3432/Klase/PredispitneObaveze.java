/***********************************************************************
 * Module:  PredispitneObaveze.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class PredispitneObaveze
 ***********************************************************************/

import java.util.*;

/** @pdOid 8726498a-8162-4c18-8878-0ffe29167a5f */
public class PredispitneObaveze {
   /** @pdOid 7d9feeb3-edfb-4ca1-913c-22f0fdf972c5 */
   private int predispitneObavezeID;
   /** @pdOid 33cecb12-0a05-4ddd-953f-aaa01459662e */
   private String naziv;
   /** @pdOid 0e3bdb12-f092-42f5-82d9-6c2152026c75 */
   private int brojObaveze;
   /** @pdOid cbcd7061-621c-4d2a-970c-be846b0a5ddc */
   private Double poeni;
   
   /** @pdRoleInfo migr=no name=TipPredispitnihObaveza assc=association21 mult=1..1 */
   public TipPredispitnihObaveza tipPredispitnihObaveza;
   
   /** @pdOid 949add65-6b5a-421e-9f30-2d56a02a214f */
   public PredispitneObaveze() {
      // TODO: implement
   }

}