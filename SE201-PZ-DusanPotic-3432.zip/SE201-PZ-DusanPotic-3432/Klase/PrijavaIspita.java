/***********************************************************************
 * Module:  PrijavaIspita.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class PrijavaIspita
 ***********************************************************************/

import java.util.*;

/** @pdOid 98418298-a062-4704-a09d-a29fd996e8b2 */
public class PrijavaIspita {
   /** @pdOid 9221c166-fe58-4b97-aefb-34fa5f753b49 */
   private int prijavaIspitaID;
   /** @pdOid 2906042e-4e6b-4cfc-a81f-db8519d0495d */
   private IspitBuilder ib;
   
   /** @pdOid 262782e6-bf04-4b1f-a359-37bb25840c4e */
   public void setIspitBuilder() {
      // TODO: implement
   }
   
   /** @pdOid f575206a-30c8-4be9-b97c-b8665ee71dc1 */
   public void createIspit() {
      // TODO: implement
   }
   
   /** @pdOid fdc05105-89b0-4ee6-ad3a-defa1e823194 */
   public Ispit getIspit() {
      // TODO: implement
      return null;
   }

}