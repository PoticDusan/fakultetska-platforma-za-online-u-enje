/***********************************************************************
 * Module:  Administrator.java
 * Author:  Dusan
 * Purpose: Defines the Class Administrator
 ***********************************************************************/

import java.util.*;

/** @pdOid 858bc5b1-ec9d-4862-b2be-9eaaebb9f2b0 */
public class Administrator extends Korisnik {
   /** @pdOid 3ac82467-27b4-4caf-be65-46f480392cd2 */
   private int adminID;
   
   /** @pdOid 863639a2-b12b-4108-b421-f324f4fbc8db */
   public Administrator() {
      // TODO: implement
   }
   
   /** @pdOid 87df510f-cc62-4ab1-b541-419db368babe */
   public int getAdminID() {
      return adminID;
   }
   
   /** @param newAdminID
    * @pdOid 63a46002-69a5-4d7b-aca0-f4b7dd5d3ac1 */
   public void setAdminID(int newAdminID) {
      adminID = newAdminID;
   }

}