/***********************************************************************
 * Module:  ModelPredmet.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class ModelPredmet
 ***********************************************************************/

import java.util.*;

/** @pdOid 8f38354b-abdc-4e6c-97a8-3161a9c79ded */
public class ModelPredmet {
   /** @pdOid 36ad3019-dfa4-44aa-8171-55f6f18ab7da */
   private int definicijaPredmetaID;
   /** @pdOid 06b78d9c-dbb6-4e69-b152-6f8d4541e2f4 */
   private int brojDomacihZadataka;
   /** @pdOid 593fd602-4eb5-466e-bec0-c122d274c2f5 */
   private int brojProjekta;
   /** @pdOid 6c93d381-28f4-4cf4-ba73-3c49b3241c83 */
   private int brojKolokvijuma;
   /** @pdOid 1e169bc0-8733-4875-9be9-469b664cb912 */
   private double poeniDomaciZadatak;
   /** @pdOid 58c67b37-5df3-4578-8185-f8fdc8e9a547 */
   private double poeniProjekat;
   /** @pdOid 33509c57-3e9c-48e8-b34c-2544ae216235 */
   private double poeniKolokvijum;
   
   /** @pdOid 5981bbfe-2805-4c1d-b1ff-979372e662e1 */
   public ModelPredmet() {
      // TODO: implement
   }

}