/***********************************************************************
 * Module:  Profesor.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Profesor
 ***********************************************************************/

import java.util.*;

/** @pdOid 6f704b67-c352-4ebe-8aa1-5977e9cab76a */
public class Profesor extends Korisnik {
   /** @pdOid 9bd711fa-87fa-49fa-befe-9750eb18ab6d */
   private int profesorID;
   /** @pdOid 10ced783-49fd-4a41-befc-dbe28d7d7a69 */
   private String zvanje;
   
   /** @pdOid a0f950cf-4cbd-44cb-a364-be8834ffce90 */
   public Profesor() {
      // TODO: implement
   }
   
   /** @param oldProfesor
    * @pdOid 53fe63f8-e72e-4268-99b7-87fd1b1542ab */
   public Profesor(Profesor oldProfesor) {
      profesorID = oldProfesor.profesorID;
      zvanje = oldProfesor.zvanje;
   }
   
   /** @pdOid eac13c65-6c81-4430-bc2a-c5af039b03d8 */
   public int getProfesorID() {
      return profesorID;
   }
   
   /** @param newProfesorID
    * @pdOid 28a73750-adc3-429e-bcf5-8bcf1390bd11 */
   public void setProfesorID(int newProfesorID) {
      profesorID = newProfesorID;
   }
   
   /** @pdOid 26212cf6-92c4-4062-9585-b1c8e17ddf90 */
   public String getZvanje() {
      return zvanje;
   }
   
   /** @param newZvanje
    * @pdOid a47cf0bb-4948-4840-9049-729c3ee80e85 */
   public void setZvanje(String newZvanje) {
      zvanje = newZvanje;
   }

}