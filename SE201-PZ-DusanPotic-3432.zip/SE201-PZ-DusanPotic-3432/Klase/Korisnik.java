/***********************************************************************
 * Module:  Korisnik.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class Korisnik
 ***********************************************************************/

import java.util.*;

/** @pdOid 4bf76519-c194-45ba-ad73-e5a8bb1fd9cf */
public class Korisnik {
   /** @pdOid 198d09d8-0cf9-4db4-8b73-2db84547770e */
   private String username;
   /** @pdOid 4dbfb287-423a-420c-a38d-ab1d1b64acbc */
   private String password;
   /** @pdOid 3baf284e-1034-4df9-91ec-fa9d4704125d */
   private String email;
   /** @pdOid 834ddac8-c850-447a-b68d-a35dc2638912 */
   private String ime;
   /** @pdOid e87834bb-8a67-431f-84be-70b967862623 */
   private String prezime;
   /** @pdOid 8b47c1bb-f71e-46bf-b7b3-3751e01f869a */
   private Date datumRodjenja;
   /** @pdOid 855454e7-7f88-4fc8-83ac-59fb593f103d */
   private String jmbg;
   
   /** @pdOid 76066872-2bf4-4fa5-b1d0-2b4d715f6315 */
   public Korisnik() {
      // TODO: implement
   }
   
   /** @pdOid 1758e852-0d19-49c2-9658-d96281836504 */
   public String getUsername() {
      return username;
   }
   
   /** @param newUsername
    * @pdOid d19ae21d-42a7-40c8-a623-5b0f8ff0cd5e */
   public void setUsername(String newUsername) {
      username = newUsername;
   }
   
   /** @pdOid 808686fe-2ead-45aa-b901-51c60860da7e */
   public String getPassword() {
      return password;
   }
   
   /** @param newPassword
    * @pdOid 93dbab7b-1e5d-47ed-9023-35e53a4af546 */
   public void setPassword(String newPassword) {
      password = newPassword;
   }
   
   /** @pdOid 19bdf6b6-8bd0-4d05-a2ca-b6d3f1564502 */
   public String getEmail() {
      return email;
   }
   
   /** @param newEmail
    * @pdOid 9c529e13-343b-4541-b2aa-c414e4ac9896 */
   public void setEmail(String newEmail) {
      email = newEmail;
   }
   
   /** @pdOid 95040f06-2eff-4445-8196-ea690a40b3e6 */
   public String getIme() {
      return ime;
   }
   
   /** @param newIme
    * @pdOid b19dd2ff-6285-4ef3-850b-c9352712db14 */
   public void setIme(String newIme) {
      ime = newIme;
   }
   
   /** @pdOid 1a663e0d-7d6a-4ad8-81f6-d0e507953564 */
   public String getPrezime() {
      return prezime;
   }
   
   /** @param newPrezime
    * @pdOid 7539dfde-9b66-4970-bebc-93591e408dc2 */
   public void setPrezime(String newPrezime) {
      prezime = newPrezime;
   }
   
   /** @pdOid 057b7983-b146-4382-9293-d829f1560193 */
   public Date getDatumRodjenja() {
      return datumRodjenja;
   }
   
   /** @param newDatumRodjenja
    * @pdOid 480e82b0-db59-4299-a8be-ca678614e41b */
   public void setDatumRodjenja(Date newDatumRodjenja) {
      datumRodjenja = newDatumRodjenja;
   }
   
   /** @pdOid c7a96de7-dd5c-436c-b2e3-2da6b8f7c4de */
   public String getJmbg() {
      return jmbg;
   }
   
   /** @param newJmbg
    * @pdOid 132c0c5e-99a1-4b6f-8e38-9b686e188aa8 */
   public void setJmbg(String newJmbg) {
      jmbg = newJmbg;
   }
   
   /** @pdOid fbae7e41-03ba-4122-a008-293c4168ce7a */
   public void toString() {
      // TODO: implement
   }

}