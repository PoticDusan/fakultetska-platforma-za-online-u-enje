/***********************************************************************
 * Module:  TipPredispitnihObaveza.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class TipPredispitnihObaveza
 ***********************************************************************/

import java.util.*;

/** @pdOid d187ff87-5dd8-4340-bf07-05511ffef9ff */
public class TipPredispitnihObaveza {
}