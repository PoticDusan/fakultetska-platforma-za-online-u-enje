/***********************************************************************
 * Module:  ProfesorInterface.java
 * Author:  Potic-Win10
 * Purpose: Defines the Interface ProfesorInterface
 ***********************************************************************/

import java.util.*;

/** @pdOid dcdd6b0e-e366-462d-9d33-fc28060ce82e */
public interface ProfesorInterface {
   /** @param username 
    * @param password
    * @pdOid f3b4ee03-13c6-444c-98ab-2bc6fa78bfce */
   Korisnik login(String username, String password);
   /** @param p
    * @pdOid f9b5db35-0570-4658-9a55-4e091e631d63 */
   void zahtevDodajPredispitneObaveze(PredispitneObaveze p);
   /** @param i
    * @pdOid 349c778b-67e2-4c76-9079-0c954d5e5d30 */
   void zahtevDodajIspitnePoene(Ispit i);
   /** @pdOid 7fe78761-1e12-4bd4-be1d-fa7a991d7a42 */
   List<SkolskaGodina> zahtevListaSkolskihGodina();
   /** @param sk
    * @pdOid 1b5d0364-1d26-4504-bced-c24f86c257f3 */
   List<Rok> zahtevListaRokova(SkolskaGodina sk);
   /** @pdOid 237260a6-04a6-42d7-a525-aa0d0292cd08 */
   List<Smer> zahtevListaSmerova();
   /** @param s
    * @pdOid 28655982-baef-4f60-9463-72df3340c330 */
   List<Predmet> zahtevListaPredmeta(Smer s);
   /** @param p
    * @pdOid 442c68f4-9556-43cb-82c3-69835a14f1cf */
   List<Lekcija> zahtevListaLekcija(Predmet p);
   /** @param p 
    * @param s
    * @pdOid 80bac325-b24b-42f4-be80-f1353da401b1 */
   List<PredispitneObaveze> zahtevListaPredispitnihObaveza(Predmet p, Student s);
   /** @param l
    * @pdOid 879dc094-a84a-4f5e-9211-b9e4948cf419 */
   void zahtevPrikazLekcije(Lekcija l);
   /** @param p
    * @pdOid 6b0b787b-1a9d-49d5-b7f8-145bdc22366b */
   List<Student> zahtevListaStudenata(Predmet p);

}