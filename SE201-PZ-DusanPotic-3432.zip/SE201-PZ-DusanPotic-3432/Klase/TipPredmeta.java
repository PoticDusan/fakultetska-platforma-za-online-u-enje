/***********************************************************************
 * Module:  TipPredmeta.java
 * Author:  Potic-Win10
 * Purpose: Defines the Class TipPredmeta
 ***********************************************************************/

import java.util.*;

/** @pdOid ea8da041-c101-46a6-86d5-6319b1fd95e8 */
public enum TipPredmeta {
   obavezni,
   izborni;

}